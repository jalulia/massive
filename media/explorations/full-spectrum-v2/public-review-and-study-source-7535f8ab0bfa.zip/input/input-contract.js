// Standalone contract harness; production Rewired and game flow are not imported.
class InputContract {
 constructor(){this.state='attract';this.held=new Set();this.selection=1;this.confirmed=false;}
 down(key){if(this.held.has(key))return;this.held.add(key);if(this.state==='attract'){this.state='release';return;}
  if(this.state==='release')return;
  if(key==='ArrowLeft')this.selection=(this.selection+2)%3;
  if(key==='ArrowRight')this.selection=(this.selection+1)%3;
  if(key==='Enter'||key==='Space'||key==='Mouse')this.confirmed=true;
 }
 up(key){this.held.delete(key);if(this.state==='release'&&this.held.size===0)this.state='menu';}
 axis(){/* joystick motion alone never opens the prompt */}
 reset(){this.state='attract';this.held.clear();this.selection=1;this.confirmed=false;}
}
if(typeof module!=='undefined')module.exports=InputContract;
