Shader "Hidden/SpectrumMix" { Properties { _MainTex("Current",2D)="black"{} _NextTex("Next",2D)="black"{} } SubShader { Cull Off ZWrite Off ZTest Always Pass { CGPROGRAM
#pragma vertex vert_img
#pragma fragment frag
#include "UnityCG.cginc"
sampler2D _MainTex,_NextTex;float _CurrentFade,_NextFade;
fixed4 frag(v2f_img i):SV_Target {float3 a=tex2D(_MainTex,i.uv).rgb*_CurrentFade,b=tex2D(_NextTex,i.uv).rgb*_NextFade;return float4(1-(1-a)*(1-b),1);}
ENDCG } } }
