using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.Rendering;
using Massive.Cosmos;
using Massive.Orbital;
using Massive.Lattice;
// Offline, isolated camera study. Native visual prefabs + explicit scale handoffs.
public static class FullSpectrumStudy {
 static string Root=>Path.GetFullPath(Path.Combine(Application.dataPath,"../.."));
 static string[] names={"COSMOS","SINGULARITY","NOVA","DYNAMO","PULSAR","ORBITAL","HIGGS","LATTICE"};
 static string[] paths={"", "Scripts/Anomalies/SINGULARITY/LS_SINGULARITY Icon.prefab","Scripts/Level Select/LS_NOVA icon.prefab","Scripts/Level Select/LS_DYNAMO icon.prefab","Scripts/Level Select/LS_PULSAR-Icon.prefab","Scripts/Anomalies/ORBITAL/LS_ORBITAL Icon.prefab","Scripts/Level Select/LS_HIGGS-Icon.prefab","Scripts/Anomalies/LATTICE/LS_LATTICE Icon.prefab"};
 static float[] scales={.15f,4.5f,3f,1.5f,1.3f,2.2f,2.8f,3f};
 // Authored portals: a web condensation, dark aperture, stellar surface, ring node,
 // polar jet, probability lobe, contour saddle, and lattice junction.
 static Vector3[] anchors={new Vector3(.55f,.18f,-.25f),new Vector3(0,0,-.4f),new Vector3(.35f,.2f,-1.25f),new Vector3(.4f,.12f,-.6f),new Vector3(.72f,.02f,-.12f),new Vector3(.18f,.3f,-.55f),new Vector3(.15f,-.1f,-.4f),new Vector3(.05f,.03f,-.18f)};
 const float Ratio=.04f,Distance=7f,Duration=80f;
 static int currentIndex;static float currentPhase;static Matrix4x4 cosmosMatrix;
 static GameObject[] worlds=new GameObject[8];
 static List<ParticleSystem> systems=new List<ParticleSystem>();
 static OrbitalCloudVisual orbital;static LatticeLevelIcon lattice;static HiggsFieldGPU higgs;
 static void Set(object o,string n,object v){var f=o.GetType().GetField(n,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance);if(f!=null)f.SetValue(o,v);}
 static float Ease(float p){p=Mathf.Clamp01(p);return p*p*p*(p*(p*6-15)+10);}
 static void Build(Camera cam){
 for(int i=1;i<8;i++){
 var pivot=new GameObject(names[i]+" frame");worlds[i]=pivot;
 var obj=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/"+paths[i]));obj.SetActive(true);obj.transform.position=Vector3.zero;obj.transform.SetParent(pivot.transform,true);
 obj.transform.localScale*=scales[i];
 if(i==6)obj.transform.localRotation=Quaternion.Euler(12,-22,0)*obj.transform.localRotation;
 if(i==3){obj.transform.localRotation=Quaternion.Euler(35,15,0)*obj.transform.localRotation;}
 foreach(var tr in obj.GetComponentsInChildren<Transform>(true))tr.gameObject.layer=8+i;
 foreach(var p in obj.GetComponentsInChildren<ParticleSystem>(true)){
  if(i==1){var inherited=p.transform.parent.lossyScale.x/obj.transform.lossyScale.x;p.transform.localScale/=Mathf.Max(.001f,Mathf.Abs(inherited));}
  p.useAutoRandomSeed=false;p.randomSeed=(uint)(791+systems.Count);var main=p.main;main.scalingMode=ParticleSystemScalingMode.Hierarchy;
  p.Simulate(3,false,true,true);p.Pause();systems.Add(p);p.GetComponent<ParticleSystemRenderer>().maxParticleSize=.035f;
 }
 if(i==1)obj.GetComponentInChildren<Massive.Singularity.SingularityLevelIcon>(true).Rebuild();
 if(i==5){orbital=obj.GetComponentInChildren<OrbitalCloudVisual>(true);orbital.fullVolume=true;orbital.volumeTurnDegreesPerSecond=0;orbital.Rebuild();orbital.Tick(.01f);foreach(var tr in obj.GetComponentsInChildren<Transform>(true))tr.gameObject.layer=13;}
 if(i==7){lattice=obj.GetComponentInChildren<LatticeLevelIcon>(true);lattice.rotateIcon=false;lattice.dotDiameterPixels=2.7f;lattice.Rebuild();lattice.Advance(.01f);}
 if(i==6){higgs=obj.GetComponentInChildren<HiggsFieldGPU>(true);higgs.SetRampOverride01(1);for(int j=0;j<120;j++){higgs.studyTime=j/24f;higgs.StudyTick();}foreach(var h in obj.GetComponentsInChildren<HiggsStackedTopoIcon>(true)){Set(h,"autoRotate",false);Set(h,"targetCamera",cam);}}
 }
 }
 static void Tick(float t,float dt){foreach(var p in systems)if(p){p.Simulate(dt,false,false,true);p.Pause();}orbital.Tick(dt);lattice.Advance(dt);higgs.studyTime=t+5;higgs.StudyTick();}
 static string Pose(float t,Camera cam,Material mat,CommandBuffer cmd,int count){
 float q=Mathf.Repeat(t,Duration)/10f;int i=(int)q;float p=q-i;
 // Three-second recognition interval followed by a sustained exponential advance.
 float u=Ease(Mathf.InverseLerp(.18f,.96f,p));
 currentIndex=i;currentPhase=p;Vector3 a=anchors[i];float start=Distance+a.z;
 float d=start*Mathf.Pow(Distance*Ratio/start,u);
 cam.transform.position=new Vector3(a.x*Ease(u*1.4f),a.y*Ease(u*1.4f),a.z-d);
 cam.transform.rotation=Quaternion.identity;cam.fieldOfView=38;cam.nearClipPlane=.0008f;cam.farClipPlane=250;
 cam.cullingMask=0;
 int prev=(i+7)%8,next=(i+1)%8;
 Matrix4x4 cosmos=Matrix4x4.identity;bool cosmosVisible=false;
 for(int j=0;j<8;j++){
  bool visible=j==i||j==prev||j==next;
  if(!visible)continue;
  float s=j==i?1:j==next?Ratio:1/Ratio;
  Vector3 pos=j==i?Vector3.zero:j==next?a:-anchors[prev]/Ratio;
  if(j==0){cosmos=Matrix4x4.TRS(pos,Quaternion.identity,Vector3.one*s*scales[0]);cosmosVisible=true;}
  else{worlds[j].transform.position=pos;worlds[j].transform.localScale=Vector3.one*s;cam.cullingMask|=1<<(8+j);}
 }
 cosmosMatrix=cosmos;cmd.Clear();float clock=60+6*Mathf.Sin(t*Mathf.PI*2/Duration);cmd.SetGlobalVector("_Time",new Vector4(clock/20,clock,clock*2,clock*3));
 if(cosmosVisible){mat.SetMatrix("_GridToWorld",cosmos);mat.SetFloat("_Unfold",1);mat.SetFloat("_MotionTime",clock);mat.SetFloat("_Focus",-1);cmd.DrawProcedural(Matrix4x4.identity,mat,0,MeshTopology.Triangles,6,count);}
 return $"{t:F4},{names[i]},{p:F4},{u:F5},{cam.transform.position.x:F6},{cam.transform.position.y:F6},{cam.transform.position.z:F6},0,0,0";
 }
 public static void Preview(){Run(640,360,12,false);}
 public static void Master(){Run(1920,1080,24,true);}
 public static void Keys(){Run(1280,720,1,false,true);}
 static void Run(int w,int h,int fps,bool master,bool keys=false){try{
 string dir=Root+"/spectrum/"+(keys?"keys":master?"master":"preview");Directory.CreateDirectory(dir);
 var cam=new GameObject("Directed scale camera").AddComponent<Camera>();cam.enabled=false;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Color.black;cam.allowHDR=false;cam.allowMSAA=true;
 var rt=new RenderTexture(w,h,24){antiAliasing=4};rt.Create();cam.targetTexture=rt;var tex=new Texture2D(w,h,TextureFormat.RGB24,false);
 var rtNext=new RenderTexture(w,h,24){antiAliasing=4};rtNext.Create();var rtFinal=new RenderTexture(w,h,0);rtFinal.Create();var mix=new Material(Shader.Find("Hidden/SpectrumMix"));
 Build(cam);var data=CosmicWebTopology.Build(56000,90210,out var stats,1);using(var buffer=new ComputeBuffer(data.Length,CosmicWebTopology.ParticleStride)){
 buffer.SetData(data);var mat=AttractStudy.Setup(buffer,"MASSIVE/Study/SpectrumCosmos");var timeCmd=new CommandBuffer();cam.AddCommandBuffer(CameraEvent.BeforeForwardOpaque,timeCmd);var cmd=new CommandBuffer();cam.AddCommandBuffer(CameraEvent.BeforeForwardAlpha,cmd);
 var csv=new List<string>{"seconds,world,phase,zoomProgress,cameraX,cameraY,cameraZ,yaw,pitch,roll"};var timings=new List<double>();
 int count=keys?80:(int)(Duration*fps);var watch=new System.Diagnostics.Stopwatch();
 for(int f=0;f<count;f++){
 float t=(float)f/fps;csv.Add(Pose(t,cam,mat,cmd,data.Length));Tick(t,1f/fps);timeCmd.Clear();float shaderTime=60+6*Mathf.Sin(t*Mathf.PI*2/Duration);timeCmd.SetGlobalVector("_Time",new Vector4(shaderTime/20,shaderTime,shaderTime*2,shaderTime*3));watch.Restart();
 int next=(currentIndex+1)%8;
 cmd.Clear();if(currentIndex==0)cmd.DrawProcedural(Matrix4x4.identity,mat,0,MeshTopology.Triangles,6,data.Length);cam.cullingMask=currentIndex==0?0:1<<(8+currentIndex);cam.targetTexture=rt;cam.Render();
 cmd.Clear();if(next==0)cmd.DrawProcedural(Matrix4x4.identity,mat,0,MeshTopology.Triangles,6,data.Length);cam.cullingMask=next==0?0:1<<(8+next);cam.targetTexture=rtNext;cam.Render();
 mix.SetTexture("_NextTex",rtNext);mix.SetFloat("_CurrentFade",1-Ease(Mathf.InverseLerp(.53f,.84f,currentPhase)));mix.SetFloat("_NextFade",Ease(Mathf.InverseLerp(.25f,.55f,currentPhase)));Graphics.Blit(rt,rtFinal,mix);RenderTexture.active=rtFinal;tex.ReadPixels(new Rect(0,0,w,h),0,0);tex.Apply();timings.Add(watch.Elapsed.TotalMilliseconds);File.WriteAllBytes(dir+"/frame-"+f.ToString("D4")+".jpg",tex.EncodeToJPG(master?95:90));
 if(f%fps==0)Debug.Log("SPECTRUM "+t+" / "+Duration+" "+names[Mathf.Min(7,(int)(t/10))]);
 }
 File.WriteAllLines(dir+"/camera-trace.csv",csv);timings.Sort();File.WriteAllText(dir+"/metrics.txt",$"{w}x{h}; {count} frames; {fps}fps offline; render/readback median {timings[timings.Count/2]:F2}ms, p95 {timings[(int)(timings.Count*.95)]:F2}ms. GPU {SystemInfo.graphicsDeviceName}. Not a realtime benchmark.");
 cam.RemoveAllCommandBuffers();cmd.Release();timeCmd.Release();UnityEngine.Object.DestroyImmediate(mat);}
 foreach(var world in worlds)if(world)UnityEngine.Object.DestroyImmediate(world);
 RenderTexture.active=null;cam.targetTexture=null;rt.Release();rtNext.Release();rtFinal.Release();UnityEngine.Object.DestroyImmediate(tex);UnityEngine.Object.DestroyImmediate(mix);UnityEngine.Object.DestroyImmediate(cam.gameObject);
 Debug.Log("FULL_SPECTRUM_COMPLETE");EditorApplication.Exit(0);
 }catch(Exception ex){Debug.LogException(ex);EditorApplication.Exit(1);}}
}
