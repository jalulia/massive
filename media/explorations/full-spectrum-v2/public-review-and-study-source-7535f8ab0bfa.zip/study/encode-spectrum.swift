import Foundation
import AVFoundation
import CoreVideo
import CoreGraphics
import ImageIO
import CoreText

let root = URL(fileURLWithPath:CommandLine.arguments[1])
let destination = URL(fileURLWithPath:CommandLine.arguments[2])
let width=Int(CommandLine.arguments[3])!,height=Int(CommandLine.arguments[4])!,fps=Int(CommandLine.arguments[5])!,frames=Int(CommandLine.arguments[6])!,bitrate=Int(CommandLine.arguments[7])!
let writer = try AVAssetWriter(outputURL:destination,fileType:.mp4)
writer.shouldOptimizeForNetworkUse=true
let input = AVAssetWriterInput(mediaType:.video,outputSettings:[
 AVVideoCodecKey:AVVideoCodecType.h264,
 AVVideoWidthKey:width,AVVideoHeightKey:height,
 AVVideoCompressionPropertiesKey:[AVVideoAverageBitRateKey:bitrate,
 AVVideoExpectedSourceFrameRateKey:fps,AVVideoMaxKeyFrameIntervalKey:fps*2,
 AVVideoProfileLevelKey:AVVideoProfileLevelH264HighAutoLevel]])
input.expectsMediaDataInRealTime=false
let adapter = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput:input,sourcePixelBufferAttributes:[
 kCVPixelBufferPixelFormatTypeKey as String:kCVPixelFormatType_32ARGB,
 kCVPixelBufferWidthKey as String:width,kCVPixelBufferHeightKey as String:height,
 kCVPixelBufferCGImageCompatibilityKey as String:true,
 kCVPixelBufferCGBitmapContextCompatibilityKey as String:true])
writer.add(input)
guard writer.startWriting() else {fatalError("Writer startup failed: \(String(describing:writer.error))")}
writer.startSession(atSourceTime:.zero)
let startFrame=CommandLine.arguments.count>9 ? Int(Double(CommandLine.arguments[9])!*Double(fps)):0
let endFrame=CommandLine.arguments.count>10 ? Int(Double(CommandLine.arguments[10])!*Double(fps)):frames
for i in startFrame..<endFrame {
 try autoreleasepool {
  let waitStart=Date(); while !input.isReadyForMoreMediaData {if Date().timeIntervalSince(waitStart)>30 {fatalError("Encoder readiness timed out")};if writer.status == .failed {throw writer.error!};Thread.sleep(forTimeInterval:0.002)}
  let t=Double(i)/Double(fps)
  let durations=[12.0,11.0,7.0,9.0,7.0,11.0,10.0,13.0]
  var stage=0,local=t
  while stage<7 && local>=durations[stage]{local-=durations[stage];stage+=1}
  let phase=local/durations[stage],sourceFrame=(Double(stage)*10+phase*10)*Double(fps),lo=min(frames-1,Int(sourceFrame)),fraction=sourceFrame-floor(sourceFrame)
  let url=root.appendingPathComponent(String(format:"frame-%04d.jpg",lo))
  guard let source=CGImageSourceCreateWithURL(url as CFURL,nil),let image=CGImageSourceCreateImageAtIndex(source,0,nil) else {fatalError("Missing frame \(i)")}
  var buffer:CVPixelBuffer?
  CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault,adapter.pixelBufferPool!,&buffer)
  let pixel=buffer!
  CVPixelBufferLockBaseAddress(pixel,[])
  let context=CGContext(data:CVPixelBufferGetBaseAddress(pixel),width:width,height:height,bitsPerComponent:8,bytesPerRow:CVPixelBufferGetBytesPerRow(pixel),space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.noneSkipFirst.rawValue)!
  context.draw(image,in:CGRect(x:0,y:0,width:width,height:height))
  if fraction>0.0001{let nextURL=root.appendingPathComponent(String(format:"frame-%04d.jpg",(lo+1)%frames));if let nextSource=CGImageSourceCreateWithURL(nextURL as CFURL,nil),let nextImage=CGImageSourceCreateImageAtIndex(nextSource,0,nil){context.saveGState();context.setAlpha(fraction);context.draw(nextImage,in:CGRect(x:0,y:0,width:width,height:height));context.restoreGState()}}
  // Native wordmark plus quiet editorial scale annotations; raw render remains clean.
  let sc=CGFloat(width)/1920
  let space=CGColorSpaceCreateDeviceRGB();let colors=[CGColor(gray:0,alpha:0.92),CGColor(gray:0,alpha:0)] as CFArray;let grad=CGGradient(colorsSpace:space,colors:colors,locations:[0,1])!
  context.drawLinearGradient(grad,start:CGPoint(x:0,y:0),end:CGPoint(x:0,y:125*sc),options:[])
  context.drawLinearGradient(grad,start:CGPoint(x:0,y:CGFloat(height)),end:CGPoint(x:0,y:CGFloat(height)-125*sc),options:[])
  if let logoSource=CGImageSourceCreateWithURL(URL(fileURLWithPath:CommandLine.arguments[8]) as CFURL,nil),let logo=CGImageSourceCreateImageAtIndex(logoSource,0,nil){context.draw(logo,in:CGRect(x:54*sc,y:CGFloat(height)-88*sc,width:250*sc,height:51.64*sc))}
  let names=["COSMOS","SINGULARITY","NOVA","DYNAMO","PULSAR","ORBITAL","HIGGS","LATTICE"]
  let exps=["+26","+14","+12","+8","+4","−10","−18","−35"]
  let display=phase>0.84 ? (stage+1)%8 : stage
  func label(_ value:String,_ x:CGFloat,_ y:CGFloat,_ size:CGFloat,_ alpha:CGFloat){let attrs:[NSAttributedString.Key:Any] = [NSAttributedString.Key(kCTFontAttributeName as String):CTFontCreateWithName("Menlo-Regular" as CFString,size*sc,nil),NSAttributedString.Key(kCTForegroundColorAttributeName as String):CGColor(gray:0.82,alpha:alpha)];let line=CTLineCreateWithAttributedString(NSAttributedString(string:value,attributes:attrs));context.textPosition=CGPoint(x:x*sc,y:y*sc);CTLineDraw(line,context)}
  label(names[display],54,66,20,0.95)
  label("10",54,36,15,0.65);label(exps[display],77,44,10,0.65)
  label("SCALE PASSAGE  /  MOTION STUDY",1390,55,13,0.65)
  for n in 0..<8{context.setFillColor(CGColor(gray:n==display ? 0.95:0.3,alpha:1));context.fill(CGRect(x:(1390+CGFloat(n)*58)*sc,y:34*sc,width:42*sc,height:2*sc))}
  CVPixelBufferUnlockBaseAddress(pixel,[])
  guard adapter.append(pixel,withPresentationTime:CMTime(value:Int64(i-startFrame),timescale:Int32(fps))) else {throw writer.error!}
 }
}
input.markAsFinished()
writer.endSession(atSourceTime:CMTime(value:Int64(endFrame-startFrame),timescale:Int32(fps)))
let done=DispatchSemaphore(value:0)
writer.finishWriting{done.signal()};done.wait()
guard writer.status == .completed else {fatalError("Encode failed: \(String(describing:writer.error))")}
print("ENCODED \(endFrame-startFrame) frames / \(Double(endFrame-startFrame)/Double(fps)) seconds / \(width)x\(height)")
